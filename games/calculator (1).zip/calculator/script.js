let display = document.getElementById("display");
let currentInput = "";

// Function to append number to the display
function appendNumber(number) {
    if (currentInput === "0" && number !== ".") {
        currentInput = number;
    } else {
        currentInput += number;
    }
    updateDisplay();
}

// Function to append operator to the display
function appendOperator(operator) {
    if (currentInput.length === 0) return;
    let lastChar = currentInput[currentInput.length - 1];
    if ("+-*/".includes(lastChar)) {
        currentInput = currentInput.slice(0, -1);
    }
    currentInput += operator;
    updateDisplay();
}

// Function to clear the display
function clearDisplay() {
    currentInput = "";
    updateDisplay();
}

// Function to calculate the result
function calculateResult() {
    try {
        currentInput = eval(currentInput).toString();
    } catch (error) {
        currentInput = "Error";
    }
    updateDisplay();
}

// Function to delete the last character
function deleteLastCharacter() {
    currentInput = currentInput.slice(0, -1);
    updateDisplay();
}

// Update the display with current input
function updateDisplay() {
    display.innerText = currentInput || "0";
}

// Function to handle keydown events for keyboard support
function handleKeyboardInput(event) {
    const key = event.key;

    if (key >= '0' && key <= '9') {
        // Handle number keys
        appendNumber(key);
    } else if (key === '.') {
        // Handle decimal point
        appendNumber(key);
    } else if (key === '+' || key === '-' || key === '*' || key === '/') {
        // Handle operator keys
        appendOperator(key);
    } else if (key === 'Enter') {
        // Handle equals key
        calculateResult();
    } else if (key === 'Backspace') {
        // Handle backspace key (delete)
        deleteLastCharacter();
    } else if (key === 'c') {
        // Handle escape key (clear display)
        clearDisplay();
    }
}

// Add event listener to listen for keydown events
document.addEventListener('keydown', handleKeyboardInput);
